-- phpMyAdmin SQL Dump
-- version 4.0.10.14
-- http://www.phpmyadmin.net
--
-- Host: localhost:3306
-- Generation Time: Jan 25, 2017 at 12:28 PM
-- Server version: 5.6.34
-- PHP Version: 5.6.20

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `securech_vedicshadi`
--

-- --------------------------------------------------------

--
-- Table structure for table `contact_us`
--

CREATE TABLE IF NOT EXISTS `contact_us` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `name` varchar(250) DEFAULT NULL,
  `email` varchar(250) DEFAULT NULL,
  `subject` text,
  `message` text,
  `submit_date` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `contact_us`
--

INSERT INTO `contact_us` (`id`, `name`, `email`, `subject`, `message`, `submit_date`) VALUES
(1, 'shekhar', 'shekha13@gmail.com', 'membarship', 'i want membarship', '2016-12-30 01:25:23');

-- --------------------------------------------------------

--
-- Table structure for table `fullprofile`
--

CREATE TABLE IF NOT EXISTS `fullprofile` (
  `userid` int(10) NOT NULL,
  `dob` varchar(250) NOT NULL,
  `mobile_number` int(12) NOT NULL,
  `profile_for` varchar(50) NOT NULL,
  `gender` varchar(10) NOT NULL,
  `religion` varchar(50) NOT NULL,
  `veg` varchar(10) NOT NULL,
  `matirian_status` varchar(50) NOT NULL,
  `mother_toung` varchar(50) NOT NULL,
  `cast` varchar(50) NOT NULL,
  `height` varchar(100) NOT NULL,
  `body_color` varchar(250) NOT NULL,
  `father_name` varchar(250) NOT NULL,
  `mother_name` varchar(250) NOT NULL,
  `brother_sister` varchar(250) NOT NULL,
  `address` text NOT NULL,
  `education` text NOT NULL,
  `job_profile` text NOT NULL,
  `other_details` text NOT NULL,
  `describe_yourself` text NOT NULL,
  `profile_pic` varchar(250) NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`userid`),
  UNIQUE KEY `userid` (`userid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `fullprofile`
--

INSERT INTO `fullprofile` (`userid`, `dob`, `mobile_number`, `profile_for`, `gender`, `religion`, `veg`, `matirian_status`, `mother_toung`, `cast`, `height`, `body_color`, `father_name`, `mother_name`, `brother_sister`, `address`, `education`, `job_profile`, `other_details`, `describe_yourself`, `profile_pic`, `updated_at`) VALUES
(46, '1991-08-09', 2147483647, 'Self', 'Male', 'Hindu', 'No', 'Never Married', 'Assamese', 'Baniya', '', '', '', '', '', '                  \r\n                  ', '                    \r\n                  ', '                    \r\n\r\n                  ', '                    \r\n\r\n                  ', '                    \r\n                                      ', '@1.jpg', '2017-01-24 15:52:30'),
(47, '1993-01-25', 895684528, 'Self', 'Male', 'Hindu', 'No', 'Never Married', 'Assamese', 'Baniya', '', '', '', '', '', '                  \r\n                  ', '                    \r\n                  ', '                    \r\n\r\n                  ', '                    \r\n\r\n                  ', '                    \r\n                                      ', 'Screenshot_20170117-153715.png', '2017-01-25 04:12:40'),
(48, '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `members`
--

CREATE TABLE IF NOT EXISTS `members` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `name` varchar(250) DEFAULT NULL,
  `email` varchar(250) DEFAULT NULL,
  `phone_number` varchar(20) DEFAULT NULL,
  `address` text,
  `adhar_no` varchar(100) DEFAULT NULL,
  `pic` text,
  `create_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

-- --------------------------------------------------------

--
-- Table structure for table `training_contacts`
--

CREATE TABLE IF NOT EXISTS `training_contacts` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `name` varchar(250) DEFAULT NULL,
  `email` varchar(250) DEFAULT NULL,
  `phone_no` varchar(20) DEFAULT NULL,
  `adhar_no` varchar(50) DEFAULT NULL,
  `dob` varchar(20) DEFAULT NULL,
  `address` text,
  `occupation` varchar(250) DEFAULT NULL,
  `photo` text,
  `signature` varchar(250) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `training_contacts`
--

INSERT INTO `training_contacts` (`id`, `name`, `email`, `phone_no`, `adhar_no`, `dob`, `address`, `occupation`, `photo`, `signature`, `created_at`) VALUES
(1, 'n', 'dsfd@gmail.com', '78', 'adhar', '7878-07-08', 'add', 'o', 'logo11.png', 'sing', '2017-01-25 11:43:16');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `name` varchar(250) DEFAULT NULL,
  `email` varchar(250) DEFAULT NULL,
  `password` varchar(250) DEFAULT NULL,
  `verified` tinyint(1) NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `token_id` int(10) DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=49 ;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `verified`, `created_at`, `token_id`, `updated_at`) VALUES
(2, 'admin', 'admin@gmail.com', 'ec1d31d4ff7a4bfa4e5ca1df85410003', 1, NULL, 2147483647, NULL),
(46, 'chyadsv', 'shekharyadav2017@gmail.com', 'f6c65667c1b7f780ea31287b6cd7c03f', 1, '2017-01-24 15:36:02', 2147483647, '2017-01-24 15:36:02'),
(47, 'chyadsv', 'shekharyadav2017@gmail.com', '91565556484b7c2d85871a2130248fce', 1, '2017-01-25 04:10:24', 2147483647, '2017-01-25 04:10:24'),
(48, 'Vinita', 'techvedic.web@gmail.com', '91565556484b7c2d85871a2130248fce', 1, '2017-01-25 04:55:48', 2147483647, '2017-01-25 04:55:48');

--
-- Constraints for dumped tables
--

--
-- Constraints for table `fullprofile`
--
ALTER TABLE `fullprofile`
  ADD CONSTRAINT `fullprofile_ibfk_1` FOREIGN KEY (`userid`) REFERENCES `users` (`id`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
