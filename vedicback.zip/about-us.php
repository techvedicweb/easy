<?php include("header.php");?>
  <section id="aa-property-header">
    <div class="container">
      <div class="row">
        <div class="col-md-12">
        <!--   <div class="aa-property-header-inner">
            <h2>Contact</h2>
            <ol class="breadcrumb">
            <li><a href="#">HOME</a></li>            
            <li class="active">Contact</li>
          </ol>
          </div> -->
        </div>
      </div>
    </div>
  </section> 
  <!-- About us -->
  <section id="aa-about-us">
    <div class="container">
      <div class="row">
        <div class="col-md-12">
          <div class="aa-about-us-area">
            <div class="row">
              <div class="col-md-5">
                <div class="aa-about-us-left">
                  <img src="img/slider/guru.jpg" alt="image">
                </div>
              </div>
              <div class="col-md-7">
                <div class="aa-about-us-right">
                  <div class="aa-title">
                    <h2>About Us</h2>
                    <span></span>
                  </div>
                  <p><b>Vedicshadi.com  ही क्यों ?</b></p>                  
                  <ul>
                     हरे कृष्ण , हमारे आस पास बहुत सी ऐसी संस्थाए है जो शादिया करवा रही हैं. उनका एकमात्र उदेशय शादी करवान और पैसे कमान है | कुछ संस्थाए युवक - युवतियों की मिलवाने का काम कर रहे हैं और बदले मैं पैसा ले रहें है . 
परंतु वैदिक शादी संस्था का मूल उद्देश्य हैं की नए  युवक - युवतियों ko milana or unko प्रशिक्षण देंna जिससे उनका वैवाहिक जीवन सुखमय हो सके | हमारे उद्दस्य हैं की ज्यादा से ज्याद युवक -युवतियों को उनकी पसंद के अनुसार मिलवाना और शाद्दी के महत्व को बताना |

" शादी एक सेक्स का साधन नही हैं | शादी का मतलब जीवन व समाज को सुचारू रूप से चलाने से हैं   "

शादी से ही जीवन रूपी ग्रस्थो को सुरुवात होती हैं  और यदि सुरुवात के ही समय यदि आप सही चुनाव नही कर पाए तो वह शादी नरक के समान हो जाती है  और यदि सही चुनाव कर लिया तो आप का जीवन स्वर्ग बन जाता है  और ऐसे जीवन की कामना देवता गण भी करते है.तो हम साधारण मनुष्य का जीवन अति सुखमय हो जायेगा .क्या कहना - इसलिए मैं आप सभी से अनुरोध करता हूँ की आप सभी  जो नए वैवाहिक जीवन मैं बंधने जा रहे हैं  वेदीक्षादि.कॉम पर रजिस्ट्रेशन करें और अपने वैवाहिक जीवन को सफल बनाये . धन्यवाद .
                   
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
  <!-- / About us -->

<?php include("footer.php");?>