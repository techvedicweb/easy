<?php include("header.php");?>
  <section id="aa-property-header">
    <div class="container">
      <div class="row">
        <div class="col-md-12">
        <!--   <div class="aa-property-header-inner">
            <h2>Contact</h2>
            <ol class="breadcrumb">
            <li><a href="#">HOME</a></li>            
            <li class="active">Contact</li>
          </ol>
          </div> -->
        </div>
      </div>
    </div>
  </section> 
  <!-- About us -->
  <section id="aa-about-us">
    <div class="container">
      <div class="row">
        <div class="col-md-12">
          <div class="aa-about-us-area">
            <div class="row">
            <?php
            if(isset($_GET['submit'])){
             if($_GET['submit']=='success'){
            
            echo '<div class="alert alert-success">
  <strong>Success!</strong> Your Details submited successfully
</div>';
            }
            
            }
            
            ?>
              <div class="col-md-5">
                <div class="aa-about-us-left">
                  <img src="img/haapymarried.jpg" alt="image">
                </div>
              </div>
              <div class="col-md-7">
                <div class="aa-about-us-right">
                  <div class="aa-title">
                    <h2>Men & Women Training Program </h2>
                    <span></span>
                  </div>
                  <!-- <p><b>Part Time  Job  Process</b></p>   -->               
                  <ul>
                   इस कार्यक्रम के माध्यम से  पारिवारिक जीवन जीने का प्रशिक्षण देने का प्रयाश कर रहे हैं | पारिवारिक जीवन मैं आने वाली कठनाईयो को कैसे कम किया जाये  और उनका सामना कैसे किया जाए ताकि मनुष्य जीवन सुखी बन सके | इस दिशा में हमारा एक छोटा सा प्रयास है जिसमे आप यदि आप सभी का विवाह हो गया है या होने वाला ह सभी वर्गों के पुरुष , स्त्रिया भाग ले और  अपना जीवन सुखी बनाये .
मैं अपनी बात को एक और छोटे  से उदहारण द्वारा समझने का प्रयाश कर रहा हूँ   - जैसे यदि बाजार मैं कोई नई मशीन आती है तो मशीन क्या-क्या काम कर सकती है , और कितने  समय तक कर सकती है इत्यादि जानकारी उस मशीन बनाने वाली कंपनी ने एक मेन्यू के द्वारा समझाया जाता है  | और हम ठोस मेन्यू के माध्यंम से समझकर उस मशीन को  अच्छे से चलाते है | ठीक इसी  प्रकार भगवान ने पुरुष व् स्त्री  रूपी यह मशीन बनाई है | परन्तु  इस मशीन की मेन्यू जो भागवान ने बनाई है वही मेन्यू हम इस कार्यक्रम के माध्यम से प्रस्तुत करने का प्रयाश कर रहे है | जो व्यक्ति इस मेन्यू को समझकर अपने जीवन मैं उत्तार लेता है वह इस संसार के दुखमय सागर को पार कर जाता है | उसके जीवन मैं सुख और दुख मैं कोईं अंतर नही रहता वह हमेशा  आनद मैं ही रहता है  | <br><br>

                   
                  </ul>
                </div>
              </div>
              
             <br><br> इस कार्यक्रम मैं निम्नलिखित बिन्दुओ पर विस्तार पूर्वक चर्चा की जाएगी <br>
१) कोई भी शरीर पुरुष या स्त्री का कैसे बनता है ?<br>
२) कोई भी शरीर केसे कार्य करता है ?<br>
३) किसी भी शरीर को चलाने के लिए भागवान या कोई भी सकती है या नही ?<br>
४) पुरुष व्  स्त्री के शारारिक व् मानशिक बनावट मैं अंतर ?<br>
५) शादी का सही अर्थ क्या होता है ?<br>
६) वैवाहिक जीवन की समस्याए और उनका समाधान |<br>

इन छे(6)   प्रकार  के महत्वपूर्ण बिन्दुओ पर विस्तार पूर्वक प्रकाश डाला जायेगा |इस कार्यक्रम को प्रस्तुत करने के लिए जाने माने  विस्विद्यालयो के प्रोफेसर व् महान व्यक्तियों  जो वर्षो से इन बिन्दुओ पर अध्यन कर रहे है , के द्वारा प्रस्तुत किया जायेगा |<br>
यह कार्यक्रम इस विश्व के किसी भी जगह पर कर सकते है | यह कार्यक्रम सभी मनुष्य जीवन को सुचारू रूप से चलाने के लिए और मानव जीवन का उद्धार करने के प्रयास से चलाया जायेगा |
<br><br>
<style type="text/css">
  
  #pid{
    border:1px solid black;
    padding: 5px;
  }
</style>
<h4 style="margin-left:20px;">Fees</h4>
<div class="col-md-6">
   <p id="pid"><b>Urban Area  </b> </p>
   <p id="pid"><b>Singal - </b> 1500</p>
   <p id="pid"><b>Couples - </b> 2100</p>
   </div>
   
   <div class="col-md-6">
   <p id="pid"><b>Rural Area  </b> </p>
   <p id="pid"><b>Singal - </b> 1000</p>
   <p id="pid"><b>Couples - </b> 1600</p>
   </div>
   
यह प्रोग्राम छ (6) दिन का होगा और हर रविवार एक पॉइंट पर 2 से 3  घंटे  की क्लास होगी और क्लास के बाद सभी के लिए भोजन प्रसाद होगा | ये सभी सेवाएं आपकी फीस  मैं ही लिया जायेगा |
इस कार्यकम की अधिक जानकारी के लिए  कृपया यह फॉर्म भरें और 7027471102 पर व्हाट्सएप्प (whatsapp) करे  


<div class="container">
  <h3>Training Attend Form</h3>
  <form action="code/complete_profile.php" method="post" enctype="multipart/form-data">
    <div class="form-group">
      <label for="name">Name:</label>
      <input type="text" required="required" aria-required="true" name="name" placeholder="Name" class="form-control">
    </div>
    <div class="form-group">
      <label for="email">Email:</label>
      <input type="email" required="required" aria-required="true"  name="email" placeholder="Email" class="form-control">
    </div>
    
    <div class="form-group">
      <label for="email">Phone Number:</label>
      <input type="text"  name="phone_number" required  placeholder="Phone Number" class="form-control"> 
    </div>
    
 
    
    <div class="form-group">
      <label for="email">Adahar Card Number:</label>
      <input type="text" id="adahar_number" name="adahar_number" placeholder=" Adahar Card Number" class="form-control" required > 
    </div>
    
     <div class="form-group">
      <label for="email">Date of Brith:</label>
      <input type="date" required="required" aria-required="true"  name="dob" placeholder="Date of Brith" class="form-control">
    </div>
    
    
    <div class="form-group">
      <label for="email">Occupation:</label>
      <input type="text" required="required" aria-required="true"  name="occupation" placeholder="Occupation" class="form-control">
    </div>
    
      <div class="form-group">
      <label for="email">Address:</label>
     <textarea type="text" id="address" name="address" placeholder="Address" rows="6" cols="15" required class="form-control" > </textarea>
    </div>
    
        
   
    
    <div class="form-group">
      <label for="email">Photo:</label>
       <input type="file"  name="member_pic" placeholder="Upload Photo"  accept="image/*"  class="form-control" required > 
    </div>
    
     <div class="form-group">
      <label for="email">Signature:</label>
      <input type="text" required="required" aria-required="true"  name="signature" placeholder="Signature" class="form-control">
    </div>
    
   <div class="checkbox">
    <label><input type="checkbox" checked> Accept Term & Conditions</label>
  </div>
    
   
    
    
    <input type="submit" name="training_enquiry" class="btn btn-default" value="Submit">
  </form>
</div>

            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
  <!-- / About us -->

<?php include("footer.php");?>