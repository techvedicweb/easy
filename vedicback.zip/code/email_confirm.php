<?php
require_once('common.php');
if(isset($_GET['email']) && ($_GET['token'])){
$email=$_GET['email'];
$token=$_GET['token'];
$register="update users set verified='1' where email='$email'";	
$obj=Common::InsertData($register);

$login="select * from users where email='$email'";
$obj=Common::FetchData($login);
foreach($obj as $loginuser){
$id=$loginuser['id'];
$_SESSION['userid']=$loginuser['id'];
	$_SESSION['tokenid']=$loginuser['token_id'];
    $_SESSION['email']=$loginuser['email'];
echo "<script type='text/javascript'>window.location.href='../complete-profile.php?id=".$id."';</script>;";
}


//echo "<script type='text/javascript'>window.location.href='../signin.php';</script>;";
//header('Location:../signin.php');

}

?>