<?php require_once('header.php');?>
    
  <section id="aa-signin">
    <div class="container">
      <div class="row">
        <div class="col-md-12">
         <br><br><br><br><br> 
          <div class="aa-signin-area">
            <div class="aa-signin-form">
              <div class="aa-signin-form-title">
  <br><br><br>
                <h4>Email Confirmation Pending</h4>
              </div>
  
            <p>  We sent a confirmation link on your registred Email Id. kindly click on activate link on email for access this website.       </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
  
  <?php require_once('footer.php');?>