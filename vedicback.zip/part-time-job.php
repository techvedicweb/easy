<?php include("header.php");?>
  <section id="aa-property-header">
    <div class="container">
      <div class="row">
        <div class="col-md-12">
        <!--   <div class="aa-property-header-inner">
            <h2>Contact</h2>
            <ol class="breadcrumb">
            <li><a href="#">HOME</a></li>            
            <li class="active">Contact</li>
          </ol>
          </div> -->
        </div>
      </div>
    </div>
  </section> 
  <!-- About us -->
  <section id="aa-about-us">
    <div class="container">
      <div class="row">
        <div class="col-md-12">
          <div class="aa-about-us-area">
            <div class="row">
              <div class="col-md-5">
                <div class="aa-about-us-left">
                  <img src="img/slider/guru.jpg" alt="image">
                </div>
              </div>
              <div class="col-md-7">
                <div class="aa-about-us-right">
                  <div class="aa-title">
                    <h2>Part Time Job </h2>
                    <span></span>
                  </div>
                  <p><b>Part Time  Job  Process</b></p>                  
                  <ul>
                    For complete proccess contact us on our EmailId or Contact number and visit on our address.
                   
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
  <!-- / About us -->

<?php include("footer.php");?>