<?php require_once('header.php');?>

  <!-- Start Proerty header  -->
  <section id="aa-property-header">
    <div class="container">
      <div class="row">
        <div class="col-md-12">
        <!--   <div class="aa-property-header-inner">
            <h2>404 Error</h2>
            <ol class="breadcrumb">
            <li><a href="#">HOME</a></li>            
            <li class="active">404</li>
          </ol>
          </div> -->
        </div>
      </div>
    </div>
  </section> 
  <!-- End Proerty header  -->
  <section id="aa-error">
    <div class="container">
      <row>
        <div class="col-md-12">
          <div class="aa-error-area">
            <h2>404</h2>
            <p><span class="fa fa-warning"></span>Oops! The Page you requested was not found!</p>
            <a href="index.php">Back Home</a>
          </div>
        </div>
      </row>
    </div>
  </section>


  <?php require_once('footer.php');?>